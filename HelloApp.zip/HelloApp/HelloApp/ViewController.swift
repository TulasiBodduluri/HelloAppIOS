//
//  ViewController.swift
//  HelloApp
//
//  Created by Bodduluri,Tulasi on 1/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var InputOutlet: UITextField!
    
    @IBOutlet weak var displayLabelOutlet: UILabel!
    
    @IBOutlet weak var lastnameOutlet: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitButtonClicked(_ sender: UIButton) {
        //Read the input from the text field and store it in a var.
        var input = InputOutlet.text!;
        var last = lastnameOutlet.text!;
        //Perform the str interpolation and assign it to displayLabel.
        displayLabelOutlet.text = "Hello, \(input) \(last)!";
    }
    
}

